'use strict';
const catalog = require('./ko.json');
const own = (text) => Object.prototype.hasOwnProperty.call(catalog, text);
function translate(value) {
    const text = String(value);
    if (own(text)) return catalog[text];
    if (text.indexOf('\n') >= 0) return text.split('\n').map(translate).join('\n');
    return text;
}
const family = (text, fallback) => /[\uac00-\ud7a3]/.test(text) ? 'korean' : fallback;
module.exports = { translate, family };
